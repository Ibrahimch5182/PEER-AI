// src/components/Analysis.jsx
import React from 'react';

const Analysis = () => {
  return (
    <div>
      <h1>Analysis Page</h1>
      <p>This is a placeholder for the analysis results.</p>
    </div>
  );
};

export default Analysis;
